# CLAUDE.md — บริบทสำหรับ AI (อ่านไฟล์นี้ก่อนแก้โค้ดเสมอ)

> ไฟล์นี้ทำให้ AI เข้าใจโปรเจกต์ได้เร็วโดยไม่ต้องไล่อ่านทุกไฟล์ (ประหยัด token และประหยัดเวลา)
> เวลาสั่งงาน ให้บอกสั้น ๆ เจาะจงไฟล์/จุดที่จะแก้ แล้วอ้างไฟล์นี้เป็นบริบท

## นี่คืออะไร
ฐานเว็บร้านเล็ก — หน้าแรก + รายการสินค้า/บริการ + หน้ารายละเอียด + หลังบ้านแก้เนื้อหาเอง
ยังไม่มีระบบขาย/จอง/รับเงิน — ของพวกนั้นเพิ่มด้วย "บล็อก" ในโฟลเดอร์ `บล็อก/`
รันฟรีทั้งหมด: Render + MongoDB Atlas + cron-job.org

## สแตก
- Node.js + Express (ESM — `"type":"module"` ใช้ `import` ไม่ใช่ `require`)
- ฐานข้อมูล: MongoDB Atlas ผ่าน `mongodb` driver + แคชในหน่วยความจำ
  **ถ้าไม่ตั้ง `MONGODB_URI` จะ fallback ไปเก็บไฟล์ `data/db.json`** (ทดสอบเท่านั้น)
- หน้าเว็บ: HTML/CSS/JS ล้วน ไม่มี framework ไม่มี build step — แก้แล้วรีเฟรชเห็นเลย
- ไม่มี dependency นอกจาก `express` กับ `mongodb`

## แผนผังไฟล์
- `server.js` — routes ทั้งหมด (public + admin) + ยาม `requireAdmin`
- `db.js` — อ่าน/เขียนข้อมูล, `seed()` ข้อมูลตั้งต้น, ฟังก์ชันรายการและรูปภาพ
- `public/index.html` — หน้าแรก โหลดทุกอย่างจาก `GET /api/site`
- `public/item.html` — หน้ารายละเอียด อ่าน `?id=` แล้วเรียก `GET /api/items/:id`
- `public/admin.html` — หลังบ้าน ล็อกอิน + แก้เนื้อหา + จัดการรายการ + อัปรูป (ย่อรูปฝั่ง client)
- `public/privacy.html` — นโยบายความเป็นส่วนตัว (แบบร่าง)
- `public/css/styles.css` — สีทั้งหมดอยู่ในตัวแปร `--main`, `--sub`, `--ink`, `--bg` ด้านบนไฟล์

## API ที่มีอยู่
```
GET    /health                      ตอบ "ok" สั้น ๆ — cron-job.org ต้องยิงมาที่นี่เท่านั้น
GET    /api/site                    { content, items }  ← หน้าแรกใช้อันนี้อันเดียว
GET    /api/items/:id               รายการเดียว
GET    /images/:id                  รูปที่อัปไว้

POST   /api/admin/login             { password }
GET    /api/admin/content           ต้องส่ง header x-admin-password
PUT    /api/admin/content
GET    /api/admin/items
POST   /api/admin/items
PUT    /api/admin/items/:id
DELETE /api/admin/items/:id
POST   /api/admin/upload            { dataUrl } → { id, url }
GET    /api/admin/status            โหมดเก็บข้อมูล + จำนวนรายการ/รูป
```

## ศัพท์ในโค้ด (อย่าเปลี่ยนชื่อ)
- `item` = รายการสินค้า/บริการ 1 ชิ้น (ชื่อกลาง ๆ ตั้งใจ — จะเป็นสินค้า คลาส หรือบริการก็ได้)
- `content` = ข้อความและข้อมูลติดต่อทั้งเว็บ ที่แก้จากหลังบ้านได้
- `image` = รูปที่อัปแล้ว เก็บเป็น data URL อ้างถึงด้วย `/images/<id>`

## โครงข้อมูล
```js
content: { brandName, logoEmoji, tagline, heroTitle, heroText, heroImage, listTitle,
           aboutTitle, aboutText, phone, lineId, facebook, address, hours, mapUrl,
           colorMain, colorSub }
item:    { id, name, price, short, detail, image, active, order }
```

## 🔒 กติกาที่ห้ามพัง
1. **รหัสผ่านและคีย์อยู่ใน environment variables เท่านั้น** — ห้าม hardcode ลงในไฟล์ที่ push ขึ้น GitHub
2. **อย่าเปลี่ยนชื่อ route หรือชื่อ field** (`/api/site`, `item`, `content`) เว้นแต่ผู้ใช้สั่ง —
   บล็อกทุกอันในโฟลเดอร์ `บล็อก/` เขียนโดยอ้างชื่อพวกนี้
3. **`/health` ต้องตอบสั้น ๆ เสมอ** — ถ้าทำให้มันตอบยาว cron-job.org จะปิด job ทิ้งเองเพราะ "output too large"
4. **รูปต้องย่อฝั่งหน้าเว็บก่อนอัปเสมอ** (ฟังก์ชัน `shrink()` ใน admin.html) — ฐานข้อมูลฟรีมีแค่ 512MB
5. **หน้า `/admin` ห้ามมีลิงก์จากหน้า public** และห้ามใส่รหัสผ่านไว้ในไฟล์ฝั่งหน้าเว็บ
6. **เก็บ fallback ไฟล์ JSON ไว้** — ถ้าลบทิ้ง ผู้เรียนจะรันในเครื่องไม่ได้ถ้ายังไม่มี Mongo
7. **อย่าเพิ่ม framework หรือ build step** (React, Vite, TypeScript) — คลาสนี้ต้องแก้แล้วเห็นผลทันที

## แก้อะไรบ่อย แก้ตรงไหน
| อยากทำอะไร | แก้ที่ไหน |
|---|---|
| เปลี่ยนสี/ธีม | ตัวแปร `--main` `--sub` บนสุดของ `public/css/styles.css` (หรือแก้จากหลังบ้าน) |
| เปลี่ยนชื่อร้าน/โลโก้/ข้อความ | ไม่ต้องแก้โค้ด — แก้ในหน้า `/admin` |
| เพิ่มช่องข้อมูลของ item | `db.js` (`seed`, `createItem`, `updateItem`) + `public/admin.html` (ฟอร์ม) + `public/item.html` (แสดง) |
| เพิ่มข้อความใหม่ที่แก้จากหลังบ้านได้ | เพิ่ม key ใน `content` ของ `seed()` + เพิ่มช่องใน `admin.html` (`CONTENT_FIELDS`) + เรียกใช้ใน `index.html` |
| เพิ่มหน้าใหม่ | สร้าง `public/ชื่อ.html` + เพิ่ม `app.get('/ชื่อ', ...)` ใน `server.js` |
| ข้อมูลตัวอย่างตอนเริ่ม | ฟังก์ชัน `seed()` ใน `db.js` |

## รันในเครื่อง
`npm install` → `node server.js` → http://localhost:3000 (หลังบ้าน `/admin`)
