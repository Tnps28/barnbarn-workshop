// server.js — เส้นทาง (routes) ทั้งหมดของเว็บ
// หน้า public: /  /item  /privacy      หน้าหลังบ้าน: /admin
// กติกา: รหัสผ่านอยู่ใน environment variable เท่านั้น ห้ามเขียนลงในไฟล์นี้

import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import * as db from './db.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';

app.use(express.json({ limit: '8mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// ---------------------------------------------------------------- health
// cron-job.org ต้องยิงมาที่ /health เท่านั้น (ตอบสั้น ๆ ไม่ใช่ทั้งหน้าเว็บ)
app.get('/health', (req, res) => res.type('text').send('ok'));

// ---------------------------------------------------------------- public API
app.get('/api/site', (req, res) => {
  res.json({
    content: db.getContent(),
    items: db.listItems({ onlyActive: true }),
  });
});

app.get('/api/items/:id', (req, res) => {
  const item = db.getItem(req.params.id);
  if (!item || !item.active) return res.status(404).json({ error: 'ไม่พบรายการนี้' });
  res.json(item);
});

app.get('/images/:id', async (req, res) => {
  const data = await db.getImage(req.params.id);
  if (!data) return res.status(404).end();
  const m = /^data:(image\/[a-z+]+);base64,(.+)$/i.exec(data);
  if (!m) return res.status(404).end();
  res.setHeader('Cache-Control', 'public, max-age=86400');
  res.type(m[1]).send(Buffer.from(m[2], 'base64'));
});

// ---------------------------------------------------------------- ยามหน้าประตูหลังบ้าน
function requireAdmin(req, res, next) {
  if (!ADMIN_PASSWORD) {
    return res.status(500).json({ error: 'ยังไม่ได้ตั้ง ADMIN_PASSWORD ใน environment variables' });
  }
  const pass = req.get('x-admin-password') || '';
  if (pass !== ADMIN_PASSWORD) return res.status(401).json({ error: 'รหัสผ่านไม่ถูกต้อง' });
  next();
}

app.post('/api/admin/login', (req, res) => {
  if (!ADMIN_PASSWORD) return res.status(500).json({ error: 'ยังไม่ได้ตั้ง ADMIN_PASSWORD' });
  if ((req.body?.password || '') !== ADMIN_PASSWORD) {
    return res.status(401).json({ error: 'รหัสผ่านไม่ถูกต้อง' });
  }
  res.json({ ok: true, storage: db.storageMode() });
});

// ---------------------------------------------------------------- admin API
app.get('/api/admin/content', requireAdmin, (req, res) => res.json(db.getContent()));

app.put('/api/admin/content', requireAdmin, (req, res) => {
  res.json(db.saveContent(req.body || {}));
});

app.get('/api/admin/items', requireAdmin, (req, res) => res.json(db.listItems()));

app.post('/api/admin/items', requireAdmin, (req, res) => res.json(db.createItem(req.body || {})));

app.put('/api/admin/items/:id', requireAdmin, (req, res) => {
  const item = db.updateItem(req.params.id, req.body || {});
  if (!item) return res.status(404).json({ error: 'ไม่พบรายการนี้' });
  res.json(item);
});

app.delete('/api/admin/items/:id', requireAdmin, (req, res) => {
  res.json({ ok: db.deleteItem(req.params.id) });
});

// รับรูปที่ย่อแล้วจากหน้าเว็บ (ดูกติกาข้อ 4 ใน CLAUDE.md)
app.post('/api/admin/upload', requireAdmin, async (req, res) => {
  const dataUrl = req.body?.dataUrl || '';
  if (!/^data:image\//.test(dataUrl)) return res.status(400).json({ error: 'ไม่ใช่ไฟล์รูป' });
  if (dataUrl.length > 900_000) {
    return res.status(400).json({ error: 'รูปใหญ่เกินไป — ต้องย่อก่อนอัป' });
  }
  const id = await db.addImage(dataUrl);
  res.json({ id, url: '/images/' + id });
});

app.get('/api/admin/status', requireAdmin, async (req, res) => {
  res.json({
    storage: db.storageMode(),
    items: db.listItems().length,
    images: (await db.listImages()).length,
  });
});

// ---------------------------------------------------------------- หน้าเว็บ
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));
app.get('/item', (req, res) => res.sendFile(path.join(__dirname, 'public', 'item.html')));
app.get('/privacy', (req, res) => res.sendFile(path.join(__dirname, 'public', 'privacy.html')));

// ---------------------------------------------------------------- เริ่มทำงาน
db.init().then(() => {
  app.listen(PORT, () => {
    console.log(`เว็บทำงานแล้วที่ http://localhost:${PORT}`);
    console.log(`หลังบ้านอยู่ที่   http://localhost:${PORT}/admin`);
    if (!ADMIN_PASSWORD) console.log('⚠️  ยังไม่ได้ตั้ง ADMIN_PASSWORD — เข้าหลังบ้านไม่ได้');
  });
});
