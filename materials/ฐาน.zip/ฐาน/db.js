// db.js — ชั้นข้อมูลทั้งหมดของเว็บ
// มี MONGODB_URI → เก็บใน MongoDB Atlas (ข้อมูลไม่หายตอนอัปเดตเว็บ)
// ไม่มี          → เก็บลงไฟล์ data/db.json (ใช้ตอนทดสอบในเครื่องเท่านั้น)

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { MongoClient } from 'mongodb';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const MONGODB_URI = process.env.MONGODB_URI || '';

let cache = null;      // ข้อมูลทั้งก้อนที่อยู่ในหน่วยความจำ
let col = null;        // collection "site" ใน Mongo
let imgCol = null;     // collection "images" ใน Mongo
let useMongo = false;

export function uid(prefix = 'id') {
  return prefix + '_' + Math.random().toString(36).slice(2, 9);
}

// ---------------------------------------------------------------- ข้อมูลตั้งต้น
function seed() {
  return {
    content: {
      brandName: 'ชื่อร้านของคุณ',
      logoEmoji: '🌿',
      tagline: 'คำโปรยสั้น ๆ ที่บอกว่าเราคือใคร',
      heroTitle: 'ยินดีต้อนรับ',
      heroText: 'เขียนสองสามบรรทัดว่าร้านเราขายอะไร ทำอะไรให้ลูกค้าได้บ้าง',
      heroImage: '',
      listTitle: 'รายการของเรา',
      aboutTitle: 'เกี่ยวกับเรา',
      aboutText: 'เล่าที่มาของร้านสั้น ๆ ให้ลูกค้ารู้จักเรา',
      phone: '',
      lineId: '',
      facebook: '',
      address: '',
      hours: '',
      mapUrl: '',
      colorMain: '#E2653A',
      colorSub: '#8FA46B',
    },
    items: [
      {
        id: uid('it'), name: 'ตัวอย่างรายการที่ 1', price: '250',
        short: 'คำอธิบายสั้น ๆ หนึ่งบรรทัด',
        detail: 'รายละเอียดยาว ๆ ตรงนี้ ใส่สิ่งที่ลูกค้าถามบ่อย เช่น ขนาด ระยะเวลา เงื่อนไข',
        image: '', active: true, order: 1,
      },
      {
        id: uid('it'), name: 'ตัวอย่างรายการที่ 2', price: '450',
        short: 'ลบตัวอย่างพวกนี้ทิ้งได้ในหน้าหลังบ้าน',
        detail: 'เข้าหน้า /admin แล้วแก้ได้เลย ไม่ต้องแตะโค้ด',
        image: '', active: true, order: 2,
      },
    ],
  };
}

// ---------------------------------------------------------------- ไฟล์ JSON
function ensureDir() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
}

function loadFromFile() {
  ensureDir();
  if (!fs.existsSync(DB_FILE)) {
    const data = { ...seed(), images: {} };
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
    return data;
  }
  try {
    return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  } catch {
    return { ...seed(), images: {} };
  }
}

function saveToFile(data) {
  ensureDir();
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

// ---------------------------------------------------------------- Mongo
async function initMongo() {
  const client = new MongoClient(MONGODB_URI, { serverSelectionTimeoutMS: 8000 });
  await client.connect();
  const dbName = (MONGODB_URI.split('/').pop() || '').split('?')[0] || 'mysite';
  const db = client.db(dbName);
  col = db.collection('site');
  imgCol = db.collection('images');

  let doc = await col.findOne({ _id: 'main' });
  if (!doc) {
    doc = { _id: 'main', ...seed() };
    await col.insertOne(doc);
  }
  const { _id, ...rest } = doc;
  return { ...rest, images: {} };   // รูปอ่านทีละใบ ไม่โหลดมาทั้งก้อน
}

async function persistMongo(data) {
  if (!col) return;
  const { images, ...rest } = data;
  await col.updateOne({ _id: 'main' }, { $set: rest });
}

// ---------------------------------------------------------------- init
export async function init() {
  if (MONGODB_URI) {
    try {
      cache = await initMongo();
      useMongo = true;
      console.log('✅ ต่อ MongoDB Atlas สำเร็จ — ข้อมูลจะไม่หาย');
      return;
    } catch (err) {
      console.error('⚠️  ต่อ MongoDB ไม่ได้:', err.message);
      console.error('   เช็ก connection string และ Network Access (0.0.0.0/0)');
    }
  }
  cache = loadFromFile();
  useMongo = false;
  console.log('⚠️  ยังไม่ได้ต่อฐานข้อมูล — เก็บลงไฟล์ data/db.json ชั่วคราว');
  console.log('   ถ้าขึ้น Render แบบนี้ ข้อมูลจะหายทุกครั้งที่ deploy ใหม่');
}

function read() {
  if (!cache) cache = loadFromFile();
  return cache;
}

function write(data) {
  cache = data;
  if (useMongo) persistMongo(data).catch((e) => console.error('บันทึกลง Mongo ไม่สำเร็จ:', e.message));
  else saveToFile(data);
}

export function storageMode() {
  return useMongo ? 'mongodb' : 'file';
}

// ---------------------------------------------------------------- เนื้อหาเว็บ
export function getContent() {
  return read().content;
}

export function saveContent(patch) {
  const d = read();
  d.content = { ...d.content, ...patch };
  write(d);
  return d.content;
}

// ---------------------------------------------------------------- รายการ
export function listItems({ onlyActive = false } = {}) {
  const items = read().items.slice().sort((a, b) => (a.order || 0) - (b.order || 0));
  return onlyActive ? items.filter((i) => i.active) : items;
}

export function getItem(id) {
  return read().items.find((i) => i.id === id) || null;
}

export function createItem(payload) {
  const d = read();
  const item = {
    id: uid('it'),
    name: payload.name || 'รายการใหม่',
    price: payload.price || '',
    short: payload.short || '',
    detail: payload.detail || '',
    image: payload.image || '',
    active: payload.active !== false,
    order: d.items.length + 1,
  };
  d.items.push(item);
  write(d);
  return item;
}

export function updateItem(id, patch) {
  const d = read();
  const i = d.items.findIndex((x) => x.id === id);
  if (i === -1) return null;
  d.items[i] = { ...d.items[i], ...patch, id };
  write(d);
  return d.items[i];
}

export function deleteItem(id) {
  const d = read();
  const before = d.items.length;
  d.items = d.items.filter((x) => x.id !== id);
  write(d);
  return d.items.length < before;
}

// ---------------------------------------------------------------- รูปภาพ
// เก็บเป็น data URL — ต้องย่อรูปฝั่งหน้าเว็บก่อนเสมอ (ดูกติกาใน CLAUDE.md)
export async function addImage(dataUrl) {
  const id = uid('img');
  if (useMongo) {
    await imgCol.insertOne({ _id: id, data: dataUrl, createdAt: new Date() });
  } else {
    const d = read();
    d.images = d.images || {};
    d.images[id] = dataUrl;
    write(d);
  }
  return id;
}

export async function getImage(id) {
  if (useMongo) {
    const doc = await imgCol.findOne({ _id: id });
    return doc ? doc.data : null;
  }
  const d = read();
  return (d.images || {})[id] || null;
}

export async function deleteImage(id) {
  if (useMongo) {
    await imgCol.deleteOne({ _id: id });
    return true;
  }
  const d = read();
  if (d.images && d.images[id]) {
    delete d.images[id];
    write(d);
    return true;
  }
  return false;
}

export async function listImages() {
  if (useMongo) {
    const docs = await imgCol.find({}, { projection: { _id: 1 } }).toArray();
    return docs.map((x) => x._id);
  }
  return Object.keys(read().images || {});
}
